"""Week 3: Advanced data analysis and visualization for a hypothetical logistics network.
Generates a simulated shipment dataset, runs EDA and produces seven charts."""
import numpy as np, pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns

sns.set_theme(style="whitegrid", context="notebook")
PAL = {"Road": "#2E5597", "Rail": "#5B9BD5", "Air": "#C55A11"}

# ---------- 1. Data simulation ----------
def simulate(n=6000, seed=11):
    rng = np.random.default_rng(seed)
    dates = pd.Timestamp("2025-01-01") + pd.to_timedelta(rng.integers(0, 365, n), unit="D")
    df = pd.DataFrame({
        "shipment_id": np.arange(1, n + 1),
        "ship_date": dates,
        "origin_hub": rng.choice(["Delhi", "Mumbai", "Chennai", "Kolkata"], n, p=[.32, .3, .22, .16]),
        "dest_region": rng.choice(["North", "South", "East", "West", "Central"], n, p=[.25, .25, .15, .2, .15]),
        "mode": rng.choice(["Road", "Rail", "Air"], n, p=[.62, .26, .12]),
        "carrier": rng.choice(["Carrier A", "Carrier B", "Carrier C", "Carrier D"], n, p=[.35, .3, .2, .15]),
    })
    df["distance_km"] = rng.gamma(4, 260, n).clip(60, 3200).round(0)
    df["weight_kg"] = rng.lognormal(5.2, .8, n).clip(5, 4000).round(1)
    speed = df["mode"].map({"Road": 450, "Rail": 380, "Air": 1500})           # km per day
    df["scheduled_days"] = np.ceil(df["distance_km"] / speed + df["mode"].map({"Road": 0.6, "Rail": 1.4, "Air": 0.3})).astype(int)
    m = df["ship_date"].dt.month
    peak = np.where(m.isin([10, 11, 12]), 0.9, 0.0)                              # festive-season congestion
    carrier_delay = df["carrier"].map({"Carrier A": 0.1, "Carrier B": 0.25, "Carrier C": 0.9, "Carrier D": 0.35})
    region_delay = df["dest_region"].map({"North": 0.2, "South": 0.1, "East": 0.8, "West": 0.15, "Central": 0.4})
    delay = rng.gamma(1.4, 0.55, n) * (0.5 + carrier_delay + region_delay + peak) - 0.55
    df["actual_days"] = np.maximum(1, np.round(df["scheduled_days"] + delay)).astype(int)
    rate = df["mode"].map({"Road": 3.1, "Rail": 2.0, "Air": 11.5})              # cost per tonne-km scale
    df["freight_cost"] = (df["distance_km"] * (df["weight_kg"] / 1000) * rate * rng.normal(1, .08, n) + 450).round(0)
    df["fuel_surcharge_pct"] = (rng.normal(9, 2, n) + (m.isin([10, 11, 12, 1]) * 2)).clip(2, 20).round(1)
    df["dwell_hours"] = (rng.gamma(2.2, 4, n) * (1 + 0.45 * (df["origin_hub"] == "Mumbai") + 0.35 * m.isin([10, 11, 12]))).round(1)
    return df

# ---------- 2. Feature engineering ----------
def add_features(df):
    df = df.copy()
    df["delay_days"] = df["actual_days"] - df["scheduled_days"]
    df["on_time"] = (df["delay_days"] <= 0).astype(int)
    df["cost_per_km"] = df["freight_cost"] / df["distance_km"]
    df["cost_per_kg"] = df["freight_cost"] / df["weight_kg"]
    df["month"] = df["ship_date"].dt.to_period("M").dt.to_timestamp()
    df["weekday"] = df["ship_date"].dt.day_name()
    return df

# ---------- 3. Exploratory analysis ----------
def eda(df):
    num = ["distance_km", "weight_kg", "scheduled_days", "actual_days", "delay_days", "freight_cost", "dwell_hours"]
    print("Rows:", len(df), "| missing cells:", int(df.isna().sum().sum()))
    desc = df[num].agg(["mean", "median", "std", "skew"]).T.round(2)
    print(desc.to_string())
    print("Overall on-time rate: %.1f%%" % (100 * df.on_time.mean()))
    print("Mean cost per km: %.2f" % df.cost_per_km.mean())
    print(df.groupby("mode").agg(shipments=("shipment_id", "size"), ontime=("on_time", "mean"), cost=("freight_cost", "mean"),
                                 cost_km=("cost_per_km", "mean"), delay=("delay_days", "mean")).round(3).to_string())
    print(df.groupby("carrier").agg(shipments=("shipment_id", "size"), ontime=("on_time", "mean"), delay=("delay_days", "mean"),
                                    cost_km=("cost_per_km", "mean")).round(3).to_string())
    print(df.groupby("dest_region").agg(ontime=("on_time", "mean"), delay=("delay_days", "mean")).round(3).to_string())
    print(df.groupby("origin_hub").agg(dwell=("dwell_hours", "mean"), ontime=("on_time", "mean")).round(3).to_string())
    mt = df.groupby("month").agg(volume=("shipment_id", "size"), ontime=("on_time", "mean"), dwell=("dwell_hours", "mean"), cost_km=("cost_per_km", "mean"))
    print(mt.round(3).to_string())
    corr = df[num + ["fuel_surcharge_pct", "cost_per_km"]].corr().round(2)
    print(corr.to_string())
    return corr


# ---------- 3b. Statistical tests, worked example and what-if ----------
def tests_and_examples(df):
    from scipy import stats
    print("\n=== Dataset preview (first 5 rows) ===")
    print(df[["shipment_id", "ship_date", "origin_hub", "dest_region", "mode", "carrier", "distance_km",
              "weight_kg", "scheduled_days", "actual_days", "freight_cost"]].head(5).to_string(index=False))
    # chi-square: is on-time rate independent of carrier?
    ct = pd.crosstab(df["carrier"], df["on_time"])
    chi2, p, dof, _ = stats.chi2_contingency(ct)
    print("\n=== Chi-square test: carrier vs on-time ===")
    print(ct.to_string()); print(f"chi2 = {chi2:.1f}, dof = {dof}, p-value = {p:.2e}")
    # two-proportion z-test: Oct-Dec vs Jan-Sep
    q4 = df["ship_date"].dt.month >= 10
    a, b = df.loc[q4, "on_time"], df.loc[~q4, "on_time"]
    p1, p2, n1, n2 = a.mean(), b.mean(), len(a), len(b)
    pp = (a.sum() + b.sum()) / (n1 + n2); z = (p2 - p1) / np.sqrt(pp * (1 - pp) * (1 / n1 + 1 / n2))
    print("\n=== Two-proportion z-test: Jan-Sep vs Oct-Dec on-time rate ===")
    print(f"Jan-Sep: {100*p2:.1f}% (n={n2}) | Oct-Dec: {100*p1:.1f}% (n={n1}) | z = {z:.1f} | p {"< 1e-16" if 2*(1-stats.norm.cdf(abs(z))) < 1e-16 else "= %.1e" % (2*(1-stats.norm.cdf(abs(z))))}")
    # t-test: dwell time Mumbai vs others
    m = df.loc[df.origin_hub == "Mumbai", "dwell_hours"]; o = df.loc[df.origin_hub != "Mumbai", "dwell_hours"]
    t, pt = stats.ttest_ind(m, o, equal_var=False)
    print("\n=== Welch t-test: dwell hours, Mumbai vs other hubs ===")
    print(f"Mumbai {m.mean():.1f} h (n={len(m)}) | Others {o.mean():.1f} h (n={len(o)}) | t = {t:.1f} | p = {pt:.1e}")
    # worked example: one real shipment, step by step
    r = df.iloc[0]
    print("\n=== Worked example: shipment", int(r.shipment_id), "===")
    print(f"scheduled_days = {r.scheduled_days}, actual_days = {r.actual_days} -> delay_days = {r.actual_days} - {r.scheduled_days} = {r.delay_days}")
    print(f"on_time = 1 if delay_days <= 0 else 0 -> {r.on_time}")
    print(f"freight_cost = {r.freight_cost:.0f}, distance_km = {r.distance_km:.0f} -> cost_per_km = {r.freight_cost:.0f} / {r.distance_km:.0f} = {r.cost_per_km:.2f}")
    # worst lane
    lane = df[(df.carrier == "Carrier C") & (df.dest_region == "East")]
    print(f"\nWorst lane Carrier C -> East: {len(lane)} shipments, on-time {100*lane.on_time.mean():.1f}%, avg delay {lane.delay_days.mean():.2f} days")
    # what-if: Carrier C performs like Carrier B within each destination region
    ontime_b = df[df.carrier == "Carrier B"].groupby("dest_region")["on_time"].mean()
    c = df[df.carrier == "Carrier C"]
    gained = (c["dest_region"].map(ontime_b) - c["on_time"]).sum()
    print("\n=== What-if: Carrier C reaches Carrier B's on-time rate in every region ===")
    print(f"Extra on-time shipments = {gained:.0f} of {len(df)} -> overall on-time {100*df.on_time.mean():.1f}% -> {100*(df.on_time.sum()+gained)/len(df):.1f}%")
    # sanity checks
    assert df["shipment_id"].is_unique and df.isna().sum().sum() == 0 and (df["actual_days"] >= 1).all()
    print("\nSanity checks passed: unique ids, no missing values, actual_days >= 1")

# ---------- 4. Visualizations ----------
def save(fig, name):
    fig.tight_layout(); fig.savefig(name, dpi=170); plt.close(fig)

def fig1_distribution(df):
    fig, ax = plt.subplots(1, 2, figsize=(9, 3.4))
    sns.histplot(df["actual_days"], discrete=True, color="#2E5597", ax=ax[0])
    ax[0].axvline(df["actual_days"].mean(), color="#C55A11", ls="--", label=f"mean {df.actual_days.mean():.1f}")
    ax[0].set(title="Delivery time (days)", xlabel="Actual days", ylabel="Shipments"); ax[0].legend()
    sns.histplot(df["delay_days"], discrete=True, color="#5B9BD5", ax=ax[1])
    ax[1].axvline(0, color="black", lw=1)
    ax[1].set(title="Delay vs schedule (days)", xlabel="Delay days (0 = on time)", ylabel="")
    save(fig, "fig1_distribution.png")

def fig2_trend(df):
    mt = df.groupby("month").agg(volume=("shipment_id", "size"), ontime=("on_time", "mean")).reset_index()
    fig, ax = plt.subplots(figsize=(8.5, 3.4))
    ax.bar(mt["month"], mt["volume"], width=22, color="#BDD7EE", label="Shipments")
    ax.set_ylabel("Monthly shipments")
    ax2 = ax.twinx(); ax2.grid(False)
    ax2.plot(mt["month"], 100 * mt["ontime"], color="#C55A11", marker="o", label="On-time %")
    ax2.set_ylabel("On-time delivery (%)"); ax2.set_ylim(40, 100)
    ax.set_title("Monthly volume and on-time rate"); ax.set_xlabel("")
    save(fig, "fig2_trend.png")

def fig3_cost_box(df):
    fig, ax = plt.subplots(1, 2, figsize=(9, 3.6))
    sns.boxplot(data=df, x="mode", y="cost_per_km", hue="mode", palette=PAL, legend=False, order=["Road", "Rail", "Air"], ax=ax[0])
    ax[0].set(title="Cost per km by mode", xlabel="", ylabel="Cost per km"); ax[0].set_yscale("log")
    ot = (df.groupby("carrier")["on_time"].mean() * 100).reindex(["Carrier A", "Carrier B", "Carrier C", "Carrier D"])
    bars = ax[1].bar(ot.index, ot.values, color=["#5B9BD5", "#5B9BD5", "#C55A11", "#5B9BD5"])
    ax[1].bar_label(bars, fmt="%.0f%%", padding=2)
    ax[1].axhline(95, color="black", ls=":", lw=1); ax[1].text(3.45, 96, "95% target", ha="right", fontsize=8)
    ax[1].set(title="On-time delivery by carrier", xlabel="", ylabel="On-time %", ylim=(0, 105))
    save(fig, "fig3_cost_box.png")

def fig4_scatter(df):
    s = df.sample(1500, random_state=1)
    fig, ax = plt.subplots(figsize=(7.2, 4))
    sns.scatterplot(data=s, x="distance_km", y="freight_cost", hue="mode", palette=PAL, alpha=.55, s=18, ax=ax)
    ax.set(title="Freight cost vs distance (sample of 1,500)", xlabel="Distance (km)", ylabel="Freight cost")
    save(fig, "fig4_scatter.png")

def fig5_heatmap_delay(df):
    pv = df.pivot_table(index="carrier", columns="dest_region", values="on_time", aggfunc="mean") * 100
    fig, ax = plt.subplots(figsize=(6.8, 3.6))
    sns.heatmap(pv, annot=True, fmt=".0f", cmap="RdYlGn", vmin=40, vmax=95, cbar_kws={"label": "On-time %"}, ax=ax)
    ax.set(title="On-time % by carrier and destination region", xlabel="", ylabel="")
    save(fig, "fig5_heatmap_ontime.png")

def fig6_corr(corr):
    fig, ax = plt.subplots(figsize=(6.8, 5))
    mask = np.triu(np.ones_like(corr, dtype=bool))
    sns.heatmap(corr, mask=mask, annot=True, fmt=".2f", cmap="coolwarm", center=0, vmin=-1, vmax=1, ax=ax, annot_kws={"size": 7})
    ax.set_title("Correlation matrix")
    save(fig, "fig6_corr.png")


def fig7_dwell(df):
    d = df.assign(period=np.where(df["ship_date"].dt.month >= 10, "Oct-Dec", "Jan-Sep"))
    g = d.groupby(["origin_hub", "period"])["dwell_hours"].mean().reset_index()
    fig, ax = plt.subplots(figsize=(7, 3.6))
    sns.barplot(data=g, x="origin_hub", y="dwell_hours", hue="period", palette={"Jan-Sep": "#9DC3E6", "Oct-Dec": "#C55A11"}, ax=ax)
    for c in ax.containers: ax.bar_label(c, fmt="%.1f", padding=2, fontsize=8)
    ax.set(title="Average hub dwell time (hours) by hub and period", xlabel="", ylabel="Dwell hours")
    save(fig, "fig7_dwell.png")

if __name__ == "__main__":
    df = add_features(simulate())
    corr = eda(df)
    tests_and_examples(df)
    fig1_distribution(df); fig2_trend(df); fig3_cost_box(df)
    fig4_scatter(df); fig5_heatmap_delay(df); fig6_corr(corr); fig7_dwell(df)
    df.to_csv("simulated_shipments.csv", index=False)
