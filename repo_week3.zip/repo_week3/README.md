# Logistics Data Analysis (Internship Project)

Python project for the Logistics Data Analyst Internship (Weeks 1 to 3).

| Week | Report | Code |
|---|---|---|
| 1 | Logistics_Week1_Strategic_Planning_Report.docx | pipeline_demo.py |
| 2 | Logistics_Week2_Data_Preparation_Report.docx | preprocess_demo.py |
| 3 | Logistics_Week3_Analysis_Visualization_Report.docx | analysis_demo.py |

## Week 3: Advanced analysis and visualization
Simulated dataset of 6,000 shipments (4 carriers, 3 modes, 4 hubs, 2025). The script prints summary statistics,
runs a chi-square test, a two-proportion z-test and a Welch t-test, and saves 7 charts.

Key results: on-time delivery 65.3%; Carrier C 49.5% on time; East region 50.3%; Oct-Dec on-time 47.1% vs 71.5% in Jan-Sep;
Mumbai hub dwell time 13.3 h vs 9.4 h elsewhere.

## Run
```
pip install -r requirements.txt
python analysis_demo.py
```
Output: `run_output.txt` shows the console output of a full run; `fig1` to `fig7` PNG files; `simulated_shipments.csv`.
The random seed is fixed, so results are repeatable.

Note: all data is simulated, so findings show the method, not the behaviour of a real company.
